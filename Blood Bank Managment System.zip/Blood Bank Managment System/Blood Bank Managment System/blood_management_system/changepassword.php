<?php


include('user_header.php');
?>

 <div class="container">

                <div class="row no-gutters">
                    <div class="col-lg-12 col-sm-12 col-12 ad">
                        <div class="admin"><br>
                            <span>Change Password</span>
                        </div>
                        <form method="POST">
                            <br><br>

                            <span class="name">OLD PASSWORD :</span> <input name="username" type="password" class="oldpass" placeholder="  Enter Old Password"> <br><br>
                            <span class="password">CONFIRM PASSWORD  : </span><input name="password" type="password" class="conpass" placeholder="   Enter Confirm Password"> <br><br>
                           <span class="name">NEW PASSWORD :</span> <input name="username" type="password" class="newpass" placeholder="  Enter New Password"> <br><br>
                            
                            
                            <input name="submit" type="submit" class="passbtn">  <span class="adminforget">
                                    </form>

                                    </div>
                              </div>
                        </div>
                </div>

                                 


                                    <br><br>
                                    <span class="adminfoot"><i><center>© 2019,Designed & Developed by <b>DA-IICT STUDENT(MSc.IT)</b>. All Rights Reserved</center></i></span>
                                    </form>
                                    </body>
                                    </html>